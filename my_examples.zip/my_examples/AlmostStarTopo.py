# Example from random youtube video

topo = { 1 : [2, 3, 4], 
         2 : [1, 3, 4, 5],
         3 : [1, 2, 5], 
         4 : [1, 2, 5],
         5 : [2, 3, 4] }