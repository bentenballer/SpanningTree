# Example from project ppt

topo = { 1 : [2, 3], 
         2 : [1, 4],
         3 : [1, 4], 
         4 : [2, 3, 5, 6],
         5 : [4, 6],
         6 : [4, 5]}